Asmbli - AI Agents Made Easy 
Version 1.0.0 for Windows 
 
Double-click agentengine_desktop.exe to launch. 
Visit https://asmbli.ai for documentation and support. 
