Asmbli - AI Agents Made Easy
Version 1.0.0 for Windows

INSTALLATION INSTRUCTIONS:
1. Ensure your Windows version is Windows 10 or later (64-bit)
2. Double-click agentengine_desktop.exe to launch the application
3. Follow the setup wizard to configure your AI API keys
4. Start creating and deploying AI agents!

SYSTEM REQUIREMENTS:
- Windows 10 64-bit or Windows 11
- 4GB RAM (8GB recommended)
- 200MB available disk space
- Internet connection for AI API access

TROUBLESHOOTING:
- If Windows Defender blocks the app, click "More info" then "Run anyway"
- For firewall issues, allow the application through Windows Firewall
- Ensure your antivirus software isn't blocking the application

FEATURES:
- Professional AI agent deployment
- 20+ specialized agent templates
- MCP (Model Context Protocol) integration
- Context document management
- Chat interface with real-time responses
- Professional tools integration

SUPPORT:
For support and documentation, visit: https://asmbli.ai
Report issues at: https://github.com/asmbli/asmbli/issues

© 2024 Asmbli. All rights reserved.